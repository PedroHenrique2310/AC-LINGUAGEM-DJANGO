from django.contrib import admin

from lms_app.models import Professor
admin.site.register(Professor)
